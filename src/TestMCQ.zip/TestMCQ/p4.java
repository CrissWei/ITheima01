package TestMCQ;

public interface p4 {
  /*  public Book Book() { }
    public Book (Book Book) { } //////////BBB
    public void Book() { }
    public abstract Book() { }*/

    double[] marks = new double[10];
    String[] country = {"Indonesia", "Malaysia", "Singapore"};
    int[] num = {'1', '4', '6', '8'};///为什么可以啊
    char[] line = new char[50];
    double[] temp = {22.4, 12.7, 45.8, 99.2, 10.2};
}
