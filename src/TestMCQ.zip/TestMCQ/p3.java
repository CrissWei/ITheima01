package TestMCQ;

public interface p3 {

}
