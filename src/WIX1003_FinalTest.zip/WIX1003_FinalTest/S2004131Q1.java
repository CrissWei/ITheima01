package WIX1003_FinalTest;

public class S2004131Q1 {
    public static void main(String[] args) {
        System.out.println(11111);
        System.out.println("Hello World!!!");
    }
}
